const AWS = require('aws-sdk');
const dynamodb = new AWS.DynamoDB({ apiVersion: '2012-08-10' });

exports.handler = (event, context, callback) => {
\\Start Instrumentation after statement
{
        if(event.Records != undefined){
            console.log('#AR_S_' + event.Records[0].eventSourceARN.split(':')[5].split('/')[1] + ' ');
        }
        console.log('#AR_S_' + context.functionName + ' ');
}
\\End Instrumentation after statement
    console.log(event);
    var params = {
        Item: {
            "myID": {
                N: "1"
            },
            "name": {
                S: "JustAName"
            }
        },
        TableName: "Table_AR"
    };
    if (event.name != undefined && event.myID != undefined) {
        params.Item.name.S = event.name;
        params.Item.myID.N = event.myID;
    }
\\Start Instrumentation before statement
	console.log('#AR_DBA_' + params.TableName + ' ');
\\End Instrumentation before statement
    dynamodb.putItem(params, function(err, data) {
       if (err) {
            console.log(err, err.stack);
            const response = {
                statusCode: '500',
                body: err
            }
            callback(null, response);
        }
        else {
            console.log(data.Item);
            const response = {
                statusCode: '200',
                body: 'Data written '
            }
            callback(null, response);
        }
    });
};


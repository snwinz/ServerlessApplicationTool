exports.handler = (event, context, callback) => {
\\Start Instrumentation after statement
{
        if(event.Records != undefined){
            console.log('#AR_S_' + event.Records[0].eventSourceARN.split(':')[5].split('/')[1] + ' ');
        }
        console.log('#AR_S_' + context.functionName + ' ');
}
\\End Instrumentation after statement
    console.log(event);
};

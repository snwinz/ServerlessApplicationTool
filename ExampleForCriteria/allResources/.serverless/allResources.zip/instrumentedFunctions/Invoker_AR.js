const AWS = require('aws-sdk');
const lambda = new AWS.Lambda();

exports.handler = function(event, context, callback) {
\\Start Instrumentation after statement
{
        if(event.Records != undefined){
            console.log('#AR_S_' + event.Records[0].eventSourceARN.split(':')[5].split('/')[1] + ' ');
        }
        console.log('#AR_S_' + context.functionName + ' ');
}
\\End Instrumentation after statement
  let params = {
    FunctionName: 'DBWriter_AR',
    InvocationType: 'Event',
    LogType: 'Tail',
    Payload: '{ "name" : "RandomName", "myID" : "1" } '
  };
  if (event.name != undefined && event.myID != undefined) {
    let payload = JSON.parse(params.Payload);
    payload.name = event.name;
    payload.myID = event.myID;
    params.Payload = JSON.stringify(payload);
  }
\\Start Instrumentation before statement
	console.log('#AR_FI_' + params.FunctionName + ' ');
\\End Instrumentation before statement
 lambda.invoke(params, function(err, data) {
       if (err) {
            console.log(err, err.stack);
            const response = {
                statusCode: '500',
                body: err
            }
            callback(null, response);
        }
        else {
            console.log(data.Item);
            const response = {
                statusCode: '200',
                body: 'Successfully called'
            }
            callback(null, response);
        }
  });
};


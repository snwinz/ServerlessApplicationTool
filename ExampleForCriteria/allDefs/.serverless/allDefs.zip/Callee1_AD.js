exports.handler = (event, context, callback) => {
    console.log(event);
    const response = {
                statusCode: '200',
                body: 'Data was written '
            };
    callback("null"; response)
};

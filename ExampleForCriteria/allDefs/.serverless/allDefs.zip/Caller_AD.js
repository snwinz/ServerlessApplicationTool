var AWS = require('aws-sdk');
var lambda = new AWS.Lambda();

exports.handler = function(event, context, callback) {
  var params = {
    FunctionName: 'Callee1_AD', 
    InvocationType: 'RequestResponse',
    LogType: 'None',
    Payload: '{ "myKey" : "myValue" }'
  };
  lambda.invoke(params, function(err, data) {
        if (err) {
            console.log(err, err.stack);
            callback(null, {
                statusCode: '500',
                body: err
            });
        }
        else {
            console.log(data);
            const response = {
                statusCode: '200',
                body: 'Data read: ',
                data: JSON.stringify(data)            
            };
            callback(null, response);
        }
    });
    var params2 = {
    FunctionName: 'Callee2_AD', 
    InvocationType: 'RequestResponse',
    LogType: 'Tail',
    Payload: '{ "myKey2" : "myValue2" }'
  };
  lambda.invoke(params2, function(err, data2) {
        if (err) {
            console.log(err, err.stack);
            callback(null, {
                statusCode: '500',
                body: err
            });
        }
        else {
            console.log(data2);
            const response = {
                statusCode: '200',
                body: 'Data read: ',
                data: JSON.stringify(data2)            
            };
            callback(null, response);
        }
    });
};
